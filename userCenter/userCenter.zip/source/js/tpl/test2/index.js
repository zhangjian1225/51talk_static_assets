;(function(root, factory) {  if (typeof module === 'object' && module.exports) module.exports = factory();  else if (typeof define === 'function') define(factory);  else root = factory();}(typeof window === 'object' ? window : this, function() {  return {"t1": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div>hello word 22223321113333</div>';

}
return __p
},
"t2": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div>t2</div>';

}
return __p
},
"t3": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div>t3333</div>';

}
return __p
},
"dd/td": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div>dddssfd</div>';

}
return __p
}}}));