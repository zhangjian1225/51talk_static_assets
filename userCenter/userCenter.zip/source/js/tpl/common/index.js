;(function(root, factory) {  if (typeof module === 'object' && module.exports) module.exports = factory();  else if (typeof define === 'function') define(factory);  else root = factory();}(typeof window === 'object' ? window : this, function() {  return {"banner": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div class="banner-box">\n    <div class="banner">\n    	<img src="?v=1526010295155" alt="topBanner">\n		<div id="timeout">\n			<i class="leftBg"></i>\n			<i class="rightBg"></i>\n			<p>\n				<i>距活动结束仅剩</i>\n				<span id="timeout_days"></span>\n				<i>天</i>\n				<span id="timeout_hours"></span>\n				<i>:</i>\n				<span id="timeout_minutes"></span>\n				<i>:</i>\n				<span id="timeout_second"></span>\n			</p>\n			<p class="default hide">活动已结束！</p>\n		</div>\n    </div>\n</div>';

}
return __p
},
"bottom": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div class="g-ft">\n    <div class="g-in f-tac">\n        <div class="links">\n            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n            <a href="http://www.51talk.com/page/about/" target="_blank" title="关于我们">关于我们</a><i>|</i>\n            <a href="//Zhaopin.51talk.com" target="_blank" title="加入我们">加入我们</a><i>|</i>\n            <a href="http://www.51talk.com/page/cet/" target="_blank" title="企业培训">企业培训</a><i>|</i>\n            <a href="http://www.51talk.com/page/o2o/" target="_blank" title="O2O代理招募">O2O代理招募</a><i>|</i>\n            <a href="http://www.51talk.com/ac/51TalkAC.php" target="_blank" title="AC客户端">AC客户端</a><i>|</i>\n            <a href="//www.51kt.com/" title="无忧课堂" target="_blank">无忧课堂</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n        </div>\n        <div class="trust">\n            <a href="http://www.51honest.org/wscredit/detail.credit?action=preLevel&credcode=NO.20000038643" target="_blank" title="信星认证" class="t1"></a>\n            <a href="http://www.itrust.org.cn/home/index/itrust_certifi/wm/1579059481.html" target="_blank" title="企业信用认证" class="t2"></a>\n            <a href="http://www.315online.com.cn/member/315120032.html" target="_blank" title="网上交易保障" class="t3"></a>\n            <a href="#" title="支付宝特约商户" class="t4"></a>\n        </div>\n        <p class="piped">Copyrigh©北京大生知行科技有限公司<i>|</i>\n            <a href="http://www.51talk.com/page/privacy/" target="_blank" title="隐私声明">隐私声明</a><i>|</i>\n            <a href="http://www.51talk.com/page/terms/" target="_blank" title="用户协议">用户协议</a><i>|</i>\n            <a href="http://www.51talk.com/page/icp/" target="_blank" title="京ICP证110696号">京ICP证110696号</a><em></em>\n            <a href="http://www.miibeian.gov.cn" target="_blank" title="京ICP备11031999号">京ICP备11031999号</a><em></em>\n            <a href="javascript:;" target="_blank" title="京公网安备11010802018414号" style="cursor:text;">京公网安备11010802018414号</a><em></em>\n        </p>\n    </div>\n    <div id="pind"></div>\n</div>';

}
return __p
},
"cartBox": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '    <!-- 购物车-->\n    <form id="form-cart" name="point_form" action="/pay/orderInfo" method="post">\n        <div class="m-cart" id="cart" style="right:-255px; "><!-- right从 0 到 -251  -->\n          <input type="hidden" name="cart" value="{&quot;cart&quot;:[],&quot;package&quot;:&quot;off&quot;,&quot;earphone&quot;:&quot;off&quot;}">\n          <div class="cart-hd"><em class="jsCount">0</em></div>\n          <div class="cart-bd"><!-- width从 0 到 251  -->\n            <div class="cart-in">\n              <div class="title">我的购物车（<em class="jsCount">0</em>）\n                <div class="u-pages">\n                  <a class="prev dis-prev" href="javascript:void(0)"></a>\n                  <span class="crt"><em class="jsPageNow">1</em><em>/</em><em class="jsPageCount">1</em></span>\n                  <a class="next dis-next" href="javascript:void(0)"></a>\n                </div>\n              </div>\n              <div class="products">\n                  <div class="jsWrap">\n                  </div>\n              </div>\n              <div class="addeds">\n                  <dl class="product" style="border-top: 1px solid rgb(228, 234, 238);">\n                      <dt class="added">\n                      <label class="u-lab jsEarphoneLabel">\n                          <input class="f-dn" type="checkbox" name="earphone">\n                          <span class="u-txt" data-cart="">+50元，选购高保真耳麦(双插头)</span>\n                      </label>\n                      </dt>\n                  </dl>\n                  <p class="differ" style="display:none;">补差价金额：\n                      <em class="jsMinuend">10288</em>&nbsp;-&nbsp;\n                      <em class="jsMeiosis">3588</em>&nbsp;=&nbsp;\n                      <em class="jsDifference">6700</em>\n                  </p>\n              </div>\n              <div class="total-orders">订单总金额：<em class="jsTotal" data-total="5799">0</em></div>\n              <div class="total-orders-stagin" style="display: none;">金额总计：<em class="jsTotal" data-total="5799"></em></div>\n              <div class="submit">\n                <input onclick="__sdonclick(\'ordersubmit\');" class="button jsSubmit" type="button" value="提交订单" style="width: 117px;">\n              </div>\n            </div>\n          </div>\n        </div>\n      </form>\n    <!-- 购物车-->';

}
return __p
},
"cart_btn": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<a class="shop-b jsCart" data-point="nor" data-cart="' +
((__t = (obj)) == null ? '' : __t) +
'" href="javascript:;">加入购物车</a>\n<a class="shop-b already-cart jsAlreadycart" href="javascript:;">已加入购物车</a>\n';

}
return __p
},
"courseInfo": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '\n    <div id="priceInfo"></div> \n    <div class="course-box">\n        <ul class="course-list f-cb" id="courseInfo">\n            ';
 for (var i = 0; i < data.length; i++) { ;
__p += '\n                    ';
 if(data[i].is_recommend == 1) {;
__p += '\n                        <li onclick="__sdonclick(\'goods-' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'-' +
((__t = ( data[i].point_type )) == null ? '' : __t) +
'\');" data-id="' +
((__t = ( data[i].id )) == null ? '' : __t) +
'" price="' +
((__t = ( data[i].price )) == null ? '' : __t) +
'" title="' +
((__t = ( data[i].name )) == null ? '' : __t) +
'" point-type="' +
((__t = ( data[i].point_type )) == null ? '' : __t) +
'" expire-days="' +
((__t = ( data[i].show_expire_days )) == null ? '' : __t) +
'" class="j-icon">\n                    ';
 }else{ ;
__p += '\n                        </li><li onclick="__sdonclick(\'goods-' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'-' +
((__t = ( data[i].point_type )) == null ? '' : __t) +
'\');" data-id="' +
((__t = ( data[i].id )) == null ? '' : __t) +
'" price="' +
((__t = ( data[i].price )) == null ? '' : __t) +
'" title="' +
((__t = ( data[i].name )) == null ? '' : __t) +
'" point-type="' +
((__t = ( data[i].point_type )) == null ? '' : __t) +
'" expire-days="' +
((__t = ( data[i].show_expire_days )) == null ? '' : __t) +
'">\n                    ';
 } ;
__p += '\n                    <span></span>\n                    <div class="li-info">\n                        <div class="child_1">\n                            ';
 if(data[i].class_time_num > 0) { ;
__p += '\n                                ';
 if(data[0].point_type == 'point_unit') { ;
__p += '\n                                    <p>' +
((__t = ( data[i].unit_num )) == null ? '' : __t) +
'单元</p>\n                                ';
 } else { ;
__p += '\n                                    <p>' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'节</p>\n                                ';
 } ;
__p += '\n                                <p class="li-des">（赠' +
((__t = ( data[i].class_time_num )) == null ? '' : __t) +
'节）</p>\n\n                            ';
 } else { ;
__p += '\n                                ';
 if(data[0].point_type == 'point_unit') { ;
__p += '\n                                    <p class="li-p">' +
((__t = ( data[i].unit_num )) == null ? '' : __t) +
'单元</p>\n                                ';
 } else { ;
__p += '\n                                    <p class="li-p">' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'节</p>\n                                ';
 } ;
__p += '  \n                            ';
 } ;
__p += '\n                        </div>\n                        <div class="child_2 hide">\n                            ';
 if(data[i].class_time_num > 0) { ;
__p += '\n                                ';
 if(data[0].point_type == 'point_unit') { ;
__p += '\n                                    <p>青少' +
((__t = ( data[i].unit_num )) == null ? '' : __t) +
'单元外教一对一课程</p>\n                                ';
 } else { ;
__p += '\n                                    <p>' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'节外教一对一课程</p>\n                                ';
 } ;
__p += '\n                                <p class="li-des">（赠送' +
((__t = ( data[i].class_time_num )) == null ? '' : __t) +
'节优选公开课）</p>\n                            ';
 } else { ;
__p += '\n                                ';
 if(data[0].point_type == 'point_unit') { ;
__p += '\n                                    <p class="li-p">青少' +
((__t = ( data[i].unit_num )) == null ? '' : __t) +
'单元外教一对一课程</p>\n                                ';
 } else { ;
__p += '\n                                    <p class="li-p">' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'节外教一对一课程</p>\n                                ';
 } ;
__p += '\n                            ';
 } ;
__p += '\n                        </div>\n                    </div>\n                    <div class="suspension-info c-icon">\n                        <span></span> \n                        ';
 if(data[0].point_type == 'point_unit') { ;
__p += '\n                            <p>青少' +
((__t = ( data[i].unit_num )) == null ? '' : __t) +
'单元（' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'节）外教一对一课程</p>\n                            ';
 if(data[i].class_time_num > 0) { ;
__p += '\n                                <p>赠送' +
((__t = ( data[i].class_time_num )) == null ? '' : __t) +
'节优选公开课</p>\n                            ';
 } ;
__p += '\n                        ';
 } else { ;
__p += '\n                            <p>' +
((__t = ( data[i].point_value )) == null ? '' : __t) +
'节外教一对一课程，';
 if(data[i].class_time_num > 0) { ;
__p += '赠送' +
((__t = ( data[i].class_time_num )) == null ? '' : __t) +
'节优选公开课';
 } ;
__p += '</p>     \n                        ';
 } ;
__p += '\n                        <p>有效期' +
((__t = ( data[i].show_expire_days )) == null ? '' : __t) +
'天</p>\n                    </div>\n                </li>\n            ';
 } ;
__p += '        \n        </ul>\n    </div>\n    <div id="installment"></div>\n    <div class="buy-btn f-cb">\n        <a onclick="__sdonclick(\'buynow\');" id="buyBtn" class="buy-b" href="javascript:;">立即购买</a>\n        <a onclick="__sdonclick(\'cartadd\');" class="shop-b jsCart" href="javascript:;">加入购物车</a>\n        <form id="buyBtnFrom" method="post" action="//sale.51talk.com/orderInfo">\n            <input id="formCard" type="hidden" name="cart" value="">\n        </form>\n    </div>';

}
return __p
},
"exBanner": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<div class="banner">\n  <ul class="p-pic">\n    <li>\n      <a href="' +
((__t = ( data.activityImageInfo.exhibition_url )) == null ? '' : __t) +
'" target="_blank"><img src="' +
((__t = ( data.activityImageInfo.exhibition_img )) == null ? '' : __t) +
'?v=1526010295197" alt=""></a>\n      <div class="silderDate">\n        <span class="d-r"></span>\n        <div class="d-timer">\n          <div class="t-lt">\n            <span>购买人数：' +
((__t = ( data.activityImageInfo.already_num )) == null ? '' : __t) +
'</span>\n          </div>\n          <div class="t-rt" data-end-time="' +
((__t = ( data.activityImageInfo.end_time )) == null ? '' : __t) +
'" data-now-time="' +
((__t = ( data.now_date )) == null ? '' : __t) +
'" id="dataTime">\n            <span class="u-t">距结束</span>\n            <span class="u-day"><i>0</i>天</span>\n            <span class="u-hour"><i>00</i>:</span>\n            <span class="u-minute"><i>00</i>:</span>\n            <span class="u-second"><i>00</i></span>\n          </div>\n        </div>\n        <span class="d-l"></span>\n      </div>\n    </li>\n    ';
 if(data.PromotionImageInfo != null) {;
__p += '\n      ';
 for (var i = 0; i < data.PromotionImageInfo.length; i++) { ;
__p += '\n        <li><a href="' +
((__t = ( data.PromotionImageInfo[i].link )) == null ? '' : __t) +
'" target="_blank"><img src="' +
((__t = ( data.PromotionImageInfo[i].image )) == null ? '' : __t) +
'?v=1526010295197" alt=""></a></li>\n      ';
 } ;
__p += '\n    ';
 } ;
__p += '\n  </ul>\n  <ul class="p-switch">\n    <li class="crt"></li>\n    ';
 if(data.PromotionImageInfo != null) {;
__p += '\n      ';
 for (var i = 0; i < data.PromotionImageInfo.length; i++) { ;
__p += '\n        <li></li>\n      ';
 } ;
__p += '\n    ';
 } ;
__p += '\n  </ul>\n</div>';

}
return __p
},
"goodItem": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '    ';
if(is_show_installment){;
__p += '\n        <dl class="product">\n                <dt class="name"><a class="jsDelete" href="javascript:;" data-id="' +
((__t = (id)) == null ? '' : __t) +
'">删除</a>' +
((__t = ( title)) == null ? '' : __t) +
'</dt>\n                <dd class="valid">' +
((__t = ((installment_price).toFixed(2))) == null ? '' : __t) +
' × ' +
((__t = (installment_num)) == null ? '' : __t) +
'期</dd>\n                <dd class="total"><em class="jsPrice">' +
((__t = ( price)) == null ? '' : __t) +
'</em><i></i></dd>\n        </dl>\n    ';
}else if(point_type=='book'){;
__p += '\n        <dl class="product">\n                <dt class="name"><a class="jsDelete" href="javascript:;" \'+\'="" data-id="' +
((__t = (id)) == null ? '' : __t) +
'">删除</a>' +
((__t = ( title)) == null ? '' : __t) +
'</dt>\n                <dd class="valid">&nbsp;</dd>\n                <dd class="total"><em class="jsPrice">' +
((__t = ( price)) == null ? '' : __t) +
'</em><i></i></dd>\n        </dl>\n    ';
}else{;
__p += '\n        <dl class="product">\n                <dt class="name"><a class="jsDelete" href="javascript:;" data-id="' +
((__t = (id)) == null ? '' : __t) +
'">删除</a>' +
((__t = ( title)) == null ? '' : __t) +
'</dt>\n                <dd class="valid">有效期：' +
((__t = (expire_days)) == null ? '' : __t) +
'天</dd>\n                <dd class="total"><em class="jsPrice">' +
((__t = (price)) == null ? '' : __t) +
'</em><i></i></dd>\n        </dl>\n    ';
};


}
return __p
},
"head": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<div class="g-hd">\n    <div class="m-top" id="jsHead">\n        <div class="g-in f-cb">\n            <div class="m-menu f-fl">\n                <a class="user __dim__o" setdata="UserMenu_username" href="//www.51talk.com/user/index">hi,\n                    <em class="nick">' +
((__t = (nick_name)) == null ? '' : __t) +
'</em>！\n                </a>\n                <i>|</i>\n                <a class="msg __dim__o" setdata="UserMenu_msg" href="//www.51talk.com/user/wll">消息\n                    ';
 if(wl_num){;
__p += '\n                        <span class="num">' +
((__t = (wl_num)) == null ? '' : __t) +
'</span>\n                    ';
};
__p += '\n                </a>\n                ';
if(is_show_weipingjia	){;
__p += '\n                    <span class="tips">\n                    <a class="txt" href="//www.51talk.com/user/review?opinion=no">您有' +
((__t = (weipingjia)) == null ? '' : __t) +
'节课程需要评价</a>\n                    <span class="close">关闭</span>\n                    </span>\n                    ';
};
__p += '\n                        <i>|</i>\n                        <a class="__dim__o" setdata="UserMenu_logout" href="//www.51talk.com/sso/logout">退出</a>\n            </div>\n            <ul class="m-link f-ib f-fr">\n                <li><a href="' +
((__t = (index_url)) == null ? '' : __t) +
'" class="__dim__o" setdata="HeadLink_1">官网首页</a></li>\n                <li><a href="//sale.51talk.com" class="__dim__o" setdata="HeadLink_2">购买课程</a></li>\n                <li>\n                    <a href="' +
((__t = (course_url)) == null ? '' : __t) +
'" class="__dim__o" setdata="HeadLink_3">课程介绍</a></li>\n                <li>\n                    <a href="//www.51talk.com/testing/index/?type=login" class="__dim__o" setdata="HeadLink_4">英语水平</a>\n                </li>\n                <li><a target="_blank" href="//www.51talk.com/page/faq" class="__dim__o" setdata="HeadLink_5">常见问题</a></li>\n                <li><a target="_blank" href="//www.51talk.com/page/cet" class="__dim__o" setdata="HeadLink_6">企业培训</a></li>\n                <li class="jsMore follow"><a href="//www.51talk.com/page/about/" class="__dim__o" setdata="HeadLink_7">关注我们</a>\n                    <ul class="jsUl">\n                        <li class="tsina"><a href="//weibo.com/51talk" rel="nofollow" target="_blank">新浪微博</a></li>\n                        <li class="tqq"><a href="//e.t.qq.com/t51talk" rel="nofollow" target="_blank">腾讯微博</a></li>\n                    </ul>\n                </li>\n                ';
if(is_show_yaoqing_link){;
__p += '\n                    <li><a href="//www.51talk.com/user/invitefriend" target="_blank" class="__dim__o" setdata="HeadLink_8">邀请有礼</a></li>\n                    ';
};
__p += '\n                        <li><a href="//www.51talk.com/activity/ipadClient" target="_blank" onclick="__sdonclick(\'ipadclient\');" title="iPad客户端">iPad客户端</a></li>\n            </ul>\n        </div>\n        <div class="down_ac" style="width:105px;height:78px;position:absolute;top:0;right:0;">\n            <a href="//www.51talk.com/ac/51TalkAC.php" target="_blank"><img src="//static.51talk.com/static/image/menber/un/down_AC.png?v=1511417080594?v=1526010295205" alt=""></a>\n        </div>\n    </div>\n    <!-- /m-top -->\n    <div class="m-head">\n        <div class="g-in">\n            <h1 class="logo"><a href="' +
((__t = (index_url)) == null ? '' : __t) +
'" class="__dim__o" setdata="nav_51talk_logo"><img src="' +
((__t = (logo_url)) == null ? '' : __t) +
'?v=1526010295205"></a></h1>\n            <ul class="nav">\n                <li class="' +
((__t = ( current_link=='index'?'crt':'')) == null ? '' : __t) +
'"><a href="//www.51talk.com/user/index" class="__dim__o" setdata="nav_1">首页</a></li>\n                <li><a href="//www.51talk.com/user/remind" class="__dim__o" setdata="nav_2">账户设置</a></li>\n                ';
if(is_show_buy_link){;
__p += '\n                    <li class="' +
((__t = ( current_link=='sale'?'crt':'')) == null ? '' : __t) +
'"><a href="//sale.51talk.com" class="__dim__o" setdata="nav_3">购买课程</a></li>\n                    ';
};
__p += '\n                        ';
if(is_show_bbs_link){;
__p += '\n                            <li><a href="//bbs.51talk.com" target="_blank" hidefocus="true" style="outline:none;" class="__dim__o" setdata="nav_4">学习社区</a></li>\n                            ';
};
__p += '\n            </ul>\n            <div class="contact">\n                <p><a href="javascript:void(0)" onclick="easemobIM()" data-type="261110" rel="nofollow" class="hiring u-b-ntkf" title="在线客服" data-url="/Ajax/countQqZiXun">客服在线咨询 (09:00-22:30)</a></p>\n                <p class="phone">4000-51-51-51</p>\n            </div>\n            ';
if(is_show_yaoqing_give_point_image){;
__p += '\n                <a class="file_style f-fr addFile addStyle0' +
((__t = ( yaoqing_give_point_week )) == null ? '' : __t) +
' __dim__o ' +
((__t = ( (yaoqing_give_point_week==5)?'add-bg':'' )) == null ? '' : __t) +
'" href="//www.51talk.com/user/invitefriend?style=' +
((__t = ( yaoqing_give_point_week)) == null ? '' : __t) +
'" setdata="nav_ad_logo" title="邀请好友送次卡 " target="_blank"></a>\n                ';
};
__p += '\n                    ';
if(is_show_yaoqing_give_course_image){;
__p += '\n                        <a class="file_style f-fr addFile addStyle01 addFrd add-frd__top>" href="//www.51talk.com/user/invitefriend" title="推荐好友有奖 获免费赠课 " target="_blank"></a>\n                        ';
};
__p += '\n        </div>\n    </div>\n    <!-- /m-head -->\n</div>';

}
return __p
},
"installment": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '\n<div class="info-text">\n    ';
 if(data.pay.is_show_installment == 1){ ;
__p += '\n        <div class="text-box f-cb">\n            <div class="tit">分期支付金额</div>\n            <div class="value">' +
((__t = ( data.pay.installment_price )) == null ? '' : __t) +
'元/月<span>（按' +
((__t = ( data.pay.installment_num )) == null ? '' : __t) +
'个月分期，每月需还款）</span></div>\n        </div>\n    ';
 } ;
__p += '\n    <div class="text-box f-cb">\n        <div class="tit">服务协议</div>\n         <div class="value"><a onclick="__sdonclick(\'agree0\');" href="' +
((__t = ( data.info.agree_url )) == null ? '' : __t) +
'" target="_blank">《' +
((__t = ( data.info.agree_name )) == null ? '' : __t) +
'》</a></div> \n    </div>\n</div> ';

}
return __p
},
"layer": function(obj) {
obj || (obj = {});
var __t, __p = '';
with (obj) {
__p += '<div class="layer-box" id="layerBox">\n    <div class="layer-main">\n        <div class="tit-box">\n            温馨提示\n            <a href="javascript:;"></a>\n        </div>\n        <div class="layer-content">\n            <p class="layer-des" id="textId"></p>\n            <div class="sure-btn">\n                <a id="layerBtn" href="javascript:;">确定</a>\n            </div>\n        </div>\n    </div>\n</div>';

}
return __p
},
"package_tab": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<ul class="tab f-cb" id="tabId">\n';
 _.each(data,function(item){ ;
__p += '\n    ';
 if(item.is_current == 1){ ;
__p += '\n        <li class="current"><a href="' +
((__t = ( item.url )) == null ? '' : __t) +
'">' +
((__t = ( item.name )) == null ? '' : __t) +
'</a></li>\n    ';
 }else{ ;
__p += '\n        <li><a href="' +
((__t = ( item.url )) == null ? '' : __t) +
'">' +
((__t = ( item.name )) == null ? '' : __t) +
'</a></li>\n    ';
 } ;
__p += '\n';
 }) ;
__p += '\n</ul>\n\n';

}
return __p
},
"price_info": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<div class="price-box">\n    <div class="p-text f-cb">\n        <span class="text text-price">价格</span>\n        <div class="text-v p-value">\n            <span>¥ </span>\n            ' +
((__t = ( data.info.avg_price )) == null ? '' : __t) +
'<span> /节</span>\n                ';
 if(data.info.avg_display > 0) { ;
__p += '\n                    <span class="cost-price">(原价：<i>￥' +
((__t = ( data.info.avg_display )) == null ? '' : __t) +
'/节</i>)</span>\n                    ';
 } ;
__p += '\n        </div>\n    </div>\n    <div class="p-text f-cb">\n        <span class="text">总价</span>\n        <div class="text-v total-price"><span>¥ </span>\n            ' +
((__t = ( data.info.price )) == null ? '' : __t) +
'\n        </div>\n    </div>\n    ';
 if( data.pay.is_cash_down == 1 || data.pay.is_straight_down == 1 || data.pay.is_give_point == 1){ ;
__p += '\n        <div class="p-text f-cb">\n            <span class="text ">活动</span>\n            <div class="text-v">\n                ';
 if(data.pay.is_cash_down == 1){ ;
__p += '\n                    满\n                    ' +
((__t = ( data.pay.cash_down_man )) == null ? '' : __t) +
'减\n                        ' +
((__t = ( data.pay.cash_down_jian )) == null ? '' : __t) +
'元;&nbsp;&nbsp;&nbsp;\n                            ';
 } ;
__p += '\n                                ';
 if(data.pay.is_straight_down == 1){ ;
__p += '\n                                    直降\n                                    ' +
((__t = ( data.pay.straight_down )) == null ? '' : __t) +
'元;&nbsp;&nbsp;&nbsp;\n                                        ';
 } ;
__p += '\n                                            ';
 if(data.pay.is_give_point == 1){ ;
__p += '\n                                                赠送\n                                                ' +
((__t = ( data.pay.give_point )) == null ? '' : __t) +
'节外教一对一课程\n                                                    ';
 } ;
__p += '\n            </div>\n        </div>\n        ';
 } ;
__p += '\n\n</div>';

}
return __p
},
"sidebar": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<div class="sidebar">\n  <ul class="menu">\n    <li class="difList learn">学习</li>\n    ';
 for(var i = 0; i < data.learning.length; i++) { ;
__p += '\n      <li><a href="' +
((__t = ( data.learning[i].link )) == null ? '' : __t) +
'" class="dirm">' +
((__t = ( data.learning[i].name )) == null ? '' : __t) +
'</a></li>\n    ';
 } ;
__p += '\n    <li class="difList exercise">练习</li>\n    ';
 for(var i = 0; i < data.practise.length; i++) { ;
__p += '\n      <li><a href="' +
((__t = ( data.practise[i].link )) == null ? '' : __t) +
'" class="dirm" target="_blank">' +
((__t = ( data.practise[i].name )) == null ? '' : __t) +
'</a></li>\n    ';
 } ;
__p += '\n    <li class="difList test">测试</li>\n    ';
 for(var i = 0; i < data.test.length; i++) { ;
__p += '\n      <li><a href="' +
((__t = ( data.test[i].link )) == null ? '' : __t) +
'" class="dirm">' +
((__t = ( data.test[i].name )) == null ? '' : __t) +
'</a></li>\n    ';
 } ;
__p += '\n    <li class="difList coach">辅导</li>\n    ';
 for(var i = 0; i < data.tutorial.length; i++) { ;
__p += '\n      <li><a href="' +
((__t = ( data.tutorial[i].link )) == null ? '' : __t) +
'" class="dirm" target="_blank">' +
((__t = ( data.tutorial[i].name )) == null ? '' : __t) +
'</a></li>\n    ';
 } ;
__p += '\n  </ul>\n  <ul class="menu service">\n    <li class="difList study">服务中心</li>\n    ';
 for(var i = 0; i < data.service_center.length; i++) { ;
__p += '\n      <li><a href="' +
((__t = ( data.service_center[i].link )) == null ? '' : __t) +
'" class="dirm">' +
((__t = ( data.service_center[i].name )) == null ? '' : __t) +
'</a></li>\n    ';
 } ;
__p += '\n    <li>\n      <div class="download">\n        软件下载<i>></i>\n        <div class="loadLayer">\n          <div>\n            ';
 for(var i = 0; i < data.downloads.length; i++) { ;
__p += '\n              <a href="' +
((__t = ( data.downloads[i].link )) == null ? '' : __t) +
'" target="_blank">' +
((__t = ( data.downloads[i].name )) == null ? '' : __t) +
'</a>\n            ';
 } ;
__p += '\n          </div>\n        </div>\n      </div>\n    </li>\n  </ul>\n  <!-- 弹出层 -->\n  <div class="alertSys">\n    <div class="hd">\n      <a class="close" href="javascript:;" title="关闭"><img src="../../images/common/alert-close.png?v=1526010295215"></a>\n      <h3>温馨提示</h3>\n    </div>\n    <div class="conText">\n      <p>您的外教1对1体验课机会已经消耗完，请联系课程顾问解决！</p>\n      <a href="javascript:;" class="knowBtn">知道了</a>\n      <a href="javascript:;" class="apply-lesson">重新申请体验课</a>\n    </div>\n  </div>\n</div>';

}
return __p
},
"sidebarRt": function(obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<div class="sideRt">\n  ';
 if(data.blackbirdcode.length) {;
__p += '\n    <ul class="mdT">\n      <li><img src="' +
((__t = ( data.blackbirdcode )) == null ? '' : __t) +
'?v=1526010295230" alt=""></li>\n      <li>您的专属课程顾问</li>\n      <li>扫描微信二维码</li>\n      <li>添加您的专属课程顾</li>\n    </ul>\n  ';
 } ;
__p += '\n  <ul class="mdC">\n    <li><img src="' +
((__t = ( data.qcode )) == null ? '' : __t) +
'?v=1526010295230" alt=""></li>\n    <li>' +
((__t = ( data.title )) == null ? '' : __t) +
'</li>\n    <li>提供上课提醒</li>\n    <li>咨询客服等服务</li>\n  </ul>\n  <ul class="mdB">\n    <li>服务中心</li>\n    <li><a href="' +
((__t = ( data.service_center )) == null ? '' : __t) +
'" target="_blank">点击进入></a></li>\n    <li><img src="../../images/common/ex_service.png?v=1526010295230" alt=""></li>\n  </ul>\n</div>';

}
return __p
}}}));