define("common/util", ['tplCommon'], function(require, exports, module) {
    module.exports = {
        replaceImgUrl:function(ele,static_url){
            var imgEles = $(ele).find("img");
            $.each(imgEles,function(i,item){
               var src =  $(item).attr("src");
               src = src.replace(/\.\.\/\.\./,static_url);
               $(item).attr('src',src);
            })
        },
        renderHeaderBottom:function(){
            var self =  this;
            self.commonTpl = require("tplCommon");
            // $.get(window.href_url+"/api/webHeader",function(res){
            //     if(res.status==1){
            //            $("#head").html(self.commonTpl.head(res.data));
            //            self.replaceImgUrl('#head',static_url);
            //             $("#bottom").html(self.commonTpl.bottom(res.data));
            //             self.replaceImgUrl('#bottom',static_url);
            //            // $("#pind").html(res.data.html_statistics);
                    
            //     }else{
            //         alert(res.info);
            //     }
            // });

            $.ajax({
              url : window.href_url+"/api/webHeader",
              type : 'get',
              dataType : 'jsonp',
              crossDomain: true,
              data : {},
              success:function(res) {
                if(res.status == 1){
                  $("#head").html(self.commonTpl.head(res.data));
                  self.replaceImgUrl('#head',static_url);
                   $("#bottom").html(self.commonTpl.bottom(res.data));
                   self.replaceImgUrl('#bottom',static_url);
                  // $("#pind").html(res.data.html_statistics);
               
                }else{
                  alert(res.info);
                }
              },
              error:function(){
                alert("接口错误");
              }
            });
       }
    }
})